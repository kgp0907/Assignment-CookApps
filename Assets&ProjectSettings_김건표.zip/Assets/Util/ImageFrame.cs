using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImageFrame : MonoBehaviour
{

    public float framerate;
    public Image SpriteImage;
    public Sprite[] sprites;
    public bool AutoStart;
    // Start is called before the first frame update

    public void StartAni(){
        if(co != null) StopCoroutine(co);

        co = StartCoroutine(frame());
    }
    void OnEnable(){
        if(co != null) StopCoroutine(co);

       if(AutoStart) co = StartCoroutine(frame());
    }

    Coroutine co;

    IEnumerator frame(){
        int f = 0;
        while (true)
        {
            SpriteImage.sprite = sprites[f];

            yield return new WaitForSeconds(framerate);
            f += 1;

            if(f >= sprites.Length) f = 0;
        }

    }
    void OnDisable(){
        if(co != null) StopCoroutine(co);

    }
}
